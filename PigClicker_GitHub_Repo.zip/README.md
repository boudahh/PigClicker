
PigClicker v1.0
===============

Features:
- Add multiple target images to auto-click
- Default image "confirm_default.png" is preloaded
- Press F8 to start/stop clicking
- Test mode (checkbox): highlights matches without clicking
- Delay slider adjusts scan frequency
- Status label shows whether it's running or paused

How to Use:
1. Launch PigClicker_v1.0.exe
2. Press F8 to toggle clicking
3. Use "Add Target Image" to load additional click targets
4. Use "Test Mode" for safe previews

Note: Clicks occur on all image matches at screen center.
